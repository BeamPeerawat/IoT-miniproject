<section class="card">
  <div class="card-header">
    <h2 class="card-title"><i class="fas fa-chart-line"></i> ข้อมูลย้อนหลัง 10 นาที</h2>
  </div>
  <div class="chart-container">
    <canvas id="sensorChart"></canvas>
  </div>
</section>