<?php
$telegram_config = [
    'bot_token' => '7422166185:AAGhIER-tM1bPLtUozN_E5-4fB8wlatrvQE',
    'chat_id' => '2140071171' // ใส่ chat_id ที่ได้จากขั้นตอนก่อนหน้า
];
?>